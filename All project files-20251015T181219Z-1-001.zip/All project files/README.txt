Open Anaconda terminal and:

If you already have an environment, activate it using:
conda activate your_environment_name

Move to the folder where main.py is stored.
cd path\to\your\project

	Example (Replace with your actual path):
	cd C:\Users\YourName\Documents\SentimentWebApp

Once inside the project folder, run following command on Anaconda:
streamlit run main.py